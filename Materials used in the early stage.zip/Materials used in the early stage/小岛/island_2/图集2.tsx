<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="图集2" tilewidth="16" tileheight="16" tilecount="1512" columns="63">
 <image source="island_2.png" width="1008" height="399"/>
</tileset>
